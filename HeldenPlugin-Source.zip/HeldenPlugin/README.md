# HeldenPlugin (Paper)

## Bauen
1. JDK (passend zur Server-Version, vermutlich 25) + Maven installieren.
2. In `pom.xml` die `paper-api`-Version auf deine exakte Paper-Version setzen.
3. `mvn package` -> `target/HeldenPlugin-1.0.0.jar` in den `plugins`-Ordner des exaroton-Servers hochladen.

## Server-Einstellungen (empfohlen)
- `server.properties`: `allow-nether=false`
- Resource Pack (hellblaue Herzen): `HeldenHUD-ResourcePack.zip` irgendwo hosten, URL + SHA-1 in
  `plugins/HeldenPlugin/config.yml` unter `resource-pack` eintragen.

## Befehle (nur Admins)
- `/allow bridges [on|off]` - Bauen ueber den Graben erlauben / verbieten
- `/helden info [spieler]`, `/helden revive <spieler>`, `/helden hearts <spieler> <0-3>`

## Welt
- Das Plugin erstellt automatisch die Welt `helden` (Name in config.yml).
- Layout (X-Achse): Westseite | Graben (224 Bloecke, komplett leer bis ins Void) | Ostseite.
  Jede Seite 4000 breit, Laenge 20000 (Z). Ausserhalb ist Void.
