package de.helden;

import de.helden.Data.PlayerState;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.object.ObjectContents;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.time.Duration;
import java.util.*;

/**
 * Herz-System:
 *  - 3 blaue Herzen (als Absorption-Herzen dargestellt, per Resource Pack hellblau)
 *  - Tod durch Spieler (15-Sekunden-Kampf-Timer) kostet ein blaues Herz
 *  - Bei 0 blauen Herzen: ein verlinktes Herz mit zufaelligem Partner
 *  - Verlinktes Herz verloren -> Spectator, Partner verliert ein blaues Herz
 */
public final class HeartListener implements Listener {

    private final HeldenPlugin plugin;
    private final Data data;
    private final Map<UUID, Long> combat = new HashMap<>();
    private final Set<UUID> pendingAnim = new HashSet<>();
    private final Random random = new Random();

    public HeartListener(HeldenPlugin plugin, Data data) {
        this.plugin = plugin;
        this.data = data;
    }

    public void startTask() {
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 10L);
    }

    // ------------------------------------------------------------------ Anzeige

    private void tick() {
        long now = System.currentTimeMillis();
        for (Player p : Bukkit.getOnlinePlayers()) {
            PlayerState s = data.getOrCreate(p);
            refresh(p, s);
            if (s.eliminated && p.getGameMode() != GameMode.SPECTATOR && !p.isDead()) {
                p.setGameMode(GameMode.SPECTATOR);
            }

            Component bar = Component.empty();
            boolean any = false;
            if (!s.eliminated && s.blue == 0) {
                if (s.partner != null) {
                    PlayerState partner = data.get(s.partner);
                    String pn = partner == null ? "?" : partner.name;
                    // Spielerkopf des Partners (Objekt-Komponente, siehe README)
                    bar = bar.append(Component.object(ObjectContents.playerHead(s.partner)))
                            .append(Component.text(" " + pn, NamedTextColor.AQUA));
                } else {
                    bar = bar.append(Component.text("Verlinktes Herz (noch kein Partner)", NamedTextColor.AQUA));
                }
                any = true;
            }
            Long end = combat.get(p.getUniqueId());
            if (end != null) {
                if (end > now) {
                    long secs = (end - now + 999) / 1000;
                    bar = bar.append(Component.text((any ? "   " : "") + "\u2694 " + secs + "s", NamedTextColor.RED));
                    any = true;
                } else {
                    combat.remove(p.getUniqueId());
                }
            }
            if (any) p.sendActionBar(bar);
        }
    }

    /** Stellt Absorption-Herzen passend zum Status ein. */
    public void refresh(Player p, PlayerState s) {
        double want = s.eliminated ? 0 : (s.blue > 0 ? s.blue * 2.0 : 2.0);
        AttributeInstance a = p.getAttribute(Attribute.MAX_ABSORPTION);
        if (a != null && Math.abs(a.getBaseValue() - want) > 0.01) a.setBaseValue(want);
        if (p.hasPotionEffect(PotionEffectType.ABSORPTION)) p.removePotionEffect(PotionEffectType.ABSORPTION);
        if (Math.abs(p.getAbsorptionAmount() - want) > 0.01) p.setAbsorptionAmount(want);
    }

    /** Verhindert, dass normaler Schaden die blauen Herzen aufbraucht. */
    @SuppressWarnings("deprecation")
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player
                && e.isApplicable(EntityDamageEvent.DamageModifier.ABSORPTION)) {
            e.setDamage(EntityDamageEvent.DamageModifier.ABSORPTION, 0);
        }
    }

    // ------------------------------------------------------------------ Kampf

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;
        Player attacker = null;
        if (e.getDamager() instanceof Player p) {
            attacker = p;
        } else if (e.getDamager() instanceof Projectile pr && pr.getShooter() instanceof Player p) {
            attacker = p;
        }
        if (attacker == null || attacker.equals(victim)) return;
        long until = System.currentTimeMillis() + plugin.getConfig().getInt("combat-seconds", 15) * 1000L;
        combat.put(victim.getUniqueId(), until);
        combat.put(attacker.getUniqueId(), until);
    }

    // ------------------------------------------------------------------ Tod

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        PlayerState s = data.getOrCreate(p);
        Long until = combat.remove(p.getUniqueId());
        if (s.eliminated) return;
        if (until == null || until < System.currentTimeMillis()) return; // normaler Tod: nichts verlieren

        Location at = p.getLocation();
        pendingAnim.add(p.getUniqueId());

        if (s.blue > 0) {
            s.blue--;
            if (s.blue == 0) assignPartner(s);
            Bukkit.broadcast(Component.text(s.name + " hat ein blaues Herz verloren! (" + s.blue + " uebrig)",
                    NamedTextColor.AQUA));
        } else {
            s.eliminated = true;
            PlayerState partner = s.partner == null ? null : data.get(s.partner);
            s.partner = null;
            Bukkit.broadcast(Component.text(s.name + " hat das verlinkte Herz verloren und ist ausgeschieden!",
                    NamedTextColor.RED));
            if (partner != null && !partner.eliminated && partner.blue > 0) {
                partner.blue--;
                if (partner.blue == 0) assignPartner(partner);
                Bukkit.broadcast(Component.text(partner.name + " verliert durch den Link ein blaues Herz! ("
                        + partner.blue + " uebrig)", NamedTextColor.AQUA));
                Player online = Bukkit.getPlayer(partner.id);
                if (online != null) {
                    refresh(online, partner);
                    animate(online.getLocation());
                }
            }
        }
        data.save();
        tryAssignOrphans();
        animate(at);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        PlayerState s = data.getOrCreate(p);
        if (s.eliminated || (!e.isBedSpawn() && !e.isAnchorSpawn())) {
            e.setRespawnLocation(plugin.spawn(s.side));
        }
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            refresh(p, s);
            if (s.eliminated) p.setGameMode(GameMode.SPECTATOR);
            if (pendingAnim.remove(p.getUniqueId())) {
                Component title = s.eliminated
                        ? Component.text("Ausgeschieden", NamedTextColor.RED)
                        : Component.text("-1 \u2764", NamedTextColor.AQUA);
                Component sub = s.eliminated
                        ? Component.text("Du bist jetzt Zuschauer")
                        : Component.text(s.blue > 0 ? "Noch " + s.blue + " blaue Herzen"
                        : "Nur noch das verlinkte Herz!");
                p.showTitle(Title.title(title, sub,
                        Title.Times.times(Duration.ofMillis(200), Duration.ofSeconds(3), Duration.ofMillis(500))));
                p.playSound(p.getLocation(), Sound.ITEM_TOTEM_USE, 1f, 1f);
            }
        }, 2L);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        boolean fresh = data.get(p.getUniqueId()) == null;
        PlayerState s = data.getOrCreate(p);

        World main = Bukkit.getWorlds().get(0);
        if (fresh || p.getWorld().equals(main)) {
            p.teleportAsync(plugin.spawn(s.side));
        }
        if (fresh) {
            p.sendMessage(Component.text("Du bist auf der " + s.side.display() + ".", NamedTextColor.GOLD));
        }

        String url = plugin.getConfig().getString("resource-pack.url", "");
        if (url != null && !url.isBlank()) {
            String sha1 = plugin.getConfig().getString("resource-pack.sha1", "");
            boolean required = plugin.getConfig().getBoolean("resource-pack.required", false);
            if (sha1 == null || sha1.isBlank()) p.setResourcePack(url);
            else p.setResourcePack(url, sha1, required);
        }

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (s.eliminated) p.setGameMode(GameMode.SPECTATOR);
            refresh(p, s);
            tryAssignOrphans();
        }, 5L);
    }

    // ------------------------------------------------------------------ Partner

    /** Waehlt zufaellig einen Partner mit mindestens 1 blauen Herz (egal welche Seite). */
    public void assignPartner(PlayerState s) {
        List<PlayerState> candidates = new ArrayList<>();
        for (PlayerState c : data.all()) {
            if (!c.id.equals(s.id) && !c.eliminated && c.blue >= 1) candidates.add(c);
        }
        s.partner = candidates.isEmpty() ? null : candidates.get(random.nextInt(candidates.size())).id;
        if (s.partner != null) {
            Player online = Bukkit.getPlayer(s.id);
            PlayerState partner = data.get(s.partner);
            if (online != null && partner != null) {
                online.sendMessage(Component.text("Dein verlinkter Partner ist jetzt " + partner.name + ".",
                        NamedTextColor.AQUA));
            }
        }
    }

    /** Spieler ohne Blau und ohne Partner bekommen einen, sobald es einen passenden gibt. */
    public void tryAssignOrphans() {
        boolean changed = false;
        for (PlayerState s : data.all()) {
            if (!s.eliminated && s.blue == 0 && s.partner == null) {
                assignPartner(s);
                if (s.partner != null) changed = true;
            }
        }
        if (changed) data.save();
    }

    // ------------------------------------------------------------------ Animation

    private void animate(Location at) {
        World w = at.getWorld();
        Location c = at.clone().add(0, 1, 0);
        w.playSound(c, Sound.ITEM_TOTEM_USE, 1.2f, 1f);
        new BukkitRunnable() {
            int t = 0;
            @Override
            public void run() {
                w.spawnParticle(Particle.TOTEM_OF_UNDYING, c, 40, 0.4, 0.7, 0.4, 0.35);
                w.spawnParticle(Particle.END_ROD, c, 12, 0.3, 0.8, 0.3, 0.05);
                if (++t >= 8) cancel();
            }
        }.runTaskTimer(plugin, 0L, 4L);
    }
}
