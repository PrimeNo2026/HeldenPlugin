package de.helden;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Skull;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * Leichen: Beim normalen Tod wird ein Spielerkopf-Block gesetzt, der Items + XP des Spielers speichert.
 * Der Block hat keine Schwerkraft, ist unzerstoerbar (ausser Admin im Creative) und kann von JEDEM geoeffnet werden.
 * Ist die Leiche leer, verschwindet sie langsam.
 */
public final class CorpseManager implements Listener {

    static final class Corpse {
        final String id;
        final UUID world;
        final int x, y, z;
        final UUID owner;
        final String ownerName;
        List<ItemStack> items;
        int xp;
        boolean fading;
        Inventory inv;

        Corpse(String id, UUID world, int x, int y, int z, UUID owner, String ownerName, List<ItemStack> items, int xp) {
            this.id = id;
            this.world = world;
            this.x = x;
            this.y = y;
            this.z = z;
            this.owner = owner;
            this.ownerName = ownerName;
            this.items = items;
            this.xp = xp;
        }
    }

    static final class Holder implements InventoryHolder {
        final Corpse corpse;
        Inventory inv;

        Holder(Corpse c) {
            this.corpse = c;
        }

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    private final HeldenPlugin plugin;
    private final File file;
    private final Map<String, Corpse> corpses = new HashMap<>();

    public CorpseManager(HeldenPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "corpses.yml");
        load();
    }

    // ------------------------------------------------------------------ Persistenz

    private static String key(UUID w, int x, int y, int z) {
        return w + ";" + x + ";" + y + ";" + z;
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection sec = y.getConfigurationSection("corpses");
        if (sec == null) return;
        for (String id : sec.getKeys(false)) {
            ConfigurationSection s = sec.getConfigurationSection(id);
            if (s == null) continue;
            try {
                byte[] bytes = Base64.getDecoder().decode(s.getString("items", ""));
                List<ItemStack> items = bytes.length == 0
                        ? new ArrayList<>() : new ArrayList<>(Arrays.asList(ItemStack.deserializeItemsFromBytes(bytes)));
                Corpse c = new Corpse(id, UUID.fromString(s.getString("world")), s.getInt("x"), s.getInt("y"), s.getInt("z"),
                        UUID.fromString(s.getString("owner")), s.getString("name", "?"), items, s.getInt("xp"));
                corpses.put(key(c.world, c.x, c.y, c.z), c);
            } catch (Exception ex) {
                plugin.getLogger().warning("Leiche " + id + " konnte nicht geladen werden: " + ex.getMessage());
            }
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Corpse c : corpses.values()) {
            String p = "corpses." + c.id;
            y.set(p + ".world", c.world.toString());
            y.set(p + ".x", c.x);
            y.set(p + ".y", c.y);
            y.set(p + ".z", c.z);
            y.set(p + ".owner", c.owner.toString());
            y.set(p + ".name", c.ownerName);
            y.set(p + ".xp", c.xp);
            byte[] bytes = c.items.isEmpty() ? new byte[0] : ItemStack.serializeItemsAsBytes(c.items);
            y.set(p + ".items", Base64.getEncoder().encodeToString(bytes));
        }
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (IOException ex) {
            plugin.getLogger().severe("Konnte corpses.yml nicht speichern: " + ex.getMessage());
        }
    }

    // ------------------------------------------------------------------ Erstellen

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        List<ItemStack> drops = new ArrayList<>();
        for (ItemStack i : e.getDrops()) {
            if (i != null && !i.getType().isAir()) drops.add(i.clone());
        }
        int xp = e.getDroppedExp();
        if (drops.isEmpty() && xp <= 0) return;

        Block spot = findSpot(p.getLocation());
        if (spot == null) return; // Fallback: normale Drops

        e.getDrops().clear();
        e.setDroppedExp(0);

        spot.setType(Material.PLAYER_HEAD, false);
        BlockState st = spot.getState();
        if (st instanceof Skull skull) {
            skull.setOwningPlayer(Bukkit.getOfflinePlayer(p.getUniqueId()));
            skull.update(true, false);
        }
        Corpse c = new Corpse(UUID.randomUUID().toString(), spot.getWorld().getUID(),
                spot.getX(), spot.getY(), spot.getZ(), p.getUniqueId(), p.getName(), drops, xp);
        corpses.put(key(c.world, c.x, c.y, c.z), c);
        save();
    }

    /** Sucht einen freien Block an der Todesstelle (nie unter der Weltgrenze, damit nichts ins Void faellt). */
    private Block findSpot(Location loc) {
        World w = loc.getWorld();
        int min = w.getMinHeight();
        int max = w.getMaxHeight() - 1;
        int x = loc.getBlockX();
        int z = loc.getBlockZ();
        int y = Math.max(min, Math.min(max, loc.getBlockY()));
        for (int i = 0; i < 8; i++) {
            int yy = y + i;
            if (yy > max) break;
            Block b = w.getBlockAt(x, yy, z);
            if ((b.getType().isAir() || b.isReplaceable()) && !corpses.containsKey(key(w.getUID(), x, yy, z))) return b;
        }
        for (int i = 1; i <= 4; i++) {
            int yy = y - i;
            if (yy < min) break;
            Block b = w.getBlockAt(x, yy, z);
            if ((b.getType().isAir() || b.isReplaceable()) && !corpses.containsKey(key(w.getUID(), x, yy, z))) return b;
        }
        return null;
    }

    private Corpse at(Block b) {
        if (b == null) return null;
        return corpses.get(key(b.getWorld().getUID(), b.getX(), b.getY(), b.getZ()));
    }

    private Block block(Corpse c) {
        World w = Bukkit.getWorld(c.world);
        return w == null ? null : w.getBlockAt(c.x, c.y, c.z);
    }

    // ------------------------------------------------------------------ Oeffnen

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getHand() != EquipmentSlot.HAND) return;
        Corpse c = at(e.getClickedBlock());
        if (c == null) return;
        e.setCancelled(true);
        if (c.fading) return;
        open(e.getPlayer(), c);
    }

    private void open(Player p, Corpse c) {
        if (c.inv == null) {
            Holder h = new Holder(c);
            h.inv = Bukkit.createInventory(h, 54, Component.text("Leiche von " + c.ownerName));
            for (ItemStack i : c.items) h.inv.addItem(i.clone());
            c.inv = h.inv;
        }
        if (c.xp > 0) {
            p.giveExp(c.xp);
            c.xp = 0;
            save();
        }
        p.openInventory(c.inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder h) {
            Bukkit.getScheduler().runTask(plugin, () -> sync(h.corpse));
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder h) {
            Bukkit.getScheduler().runTask(plugin, () -> sync(h.corpse));
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (e.getInventory().getHolder() instanceof Holder h) sync(h.corpse);
    }

    private void sync(Corpse c) {
        if (c.fading || c.inv == null) return;
        List<ItemStack> list = new ArrayList<>();
        for (ItemStack i : c.inv.getContents()) {
            if (i != null && !i.getType().isAir()) list.add(i.clone());
        }
        c.items = list;
        save();
        if (list.isEmpty() && c.xp <= 0) fade(c);
    }

    // ------------------------------------------------------------------ Verschwinden

    private void fade(Corpse c) {
        if (c.fading) return;
        c.fading = true;
        Block b = block(c);
        if (b == null) {
            remove(c);
            return;
        }
        b.getWorld().playSound(b.getLocation(), Sound.BLOCK_SOUL_SAND_BREAK, 1f, 0.6f);
        new BukkitRunnable() {
            int t = 0;
            @Override
            public void run() {
                t += 5;
                Location l = b.getLocation().add(0.5, 0.3, 0.5);
                b.getWorld().spawnParticle(Particle.ASH, l, 10, 0.25, 0.25, 0.25, 0);
                if (t >= 100) { // ca. 5 Sekunden
                    if (c.inv != null) new ArrayList<>(c.inv.getViewers()).forEach(HumanEntity::closeInventory);
                    b.setType(Material.AIR, false);
                    remove(c);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 5L);
    }

    private void remove(Corpse c) {
        corpses.remove(key(c.world, c.x, c.y, c.z));
        save();
    }

    // ------------------------------------------------------------------ Schutz

    @EventHandler(priority = EventPriority.HIGH)
    public void onBreak(BlockBreakEvent e) {
        Corpse c = at(e.getBlock());
        if (c == null) return;
        Player p = e.getPlayer();
        if (p.getGameMode() == GameMode.CREATIVE && p.hasPermission("helden.admin")) {
            for (ItemStack i : c.items) e.getBlock().getWorld().dropItemNaturally(e.getBlock().getLocation(), i);
            e.setDropItems(false);
            remove(c);
        } else {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onExplode(EntityExplodeEvent e) {
        e.blockList().removeIf(b -> at(b) != null);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onExplode(BlockExplodeEvent e) {
        e.blockList().removeIf(b -> at(b) != null);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPiston(BlockPistonExtendEvent e) {
        for (Block b : e.getBlocks()) {
            if (at(b) != null) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPiston(BlockPistonRetractEvent e) {
        for (Block b : e.getBlocks()) {
            if (at(b) != null) {
                e.setCancelled(true);
                return;
            }
        }
    }
}
