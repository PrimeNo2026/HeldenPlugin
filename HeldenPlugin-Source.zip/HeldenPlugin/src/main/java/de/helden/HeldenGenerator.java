package de.helden;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.generator.WorldInfo;

import java.util.Random;

/**
 * Nutzt die normale Minecraft-Generierung, aber nur innerhalb der beiden Seiten.
 * Der Graben in der Mitte und alles ausserhalb der Weltgrenzen bleibt komplett leer (Void).
 */
public final class HeldenGenerator extends ChunkGenerator {

    private final int trenchHalf;   // Chunks vom Zentrum bis zum Rand des Grabens
    private final int sideChunks;   // Breite einer Seite in Chunks
    private final int lenHalf;      // halbe Laenge in Chunks

    public HeldenGenerator(int trenchHalfChunks, int sideChunks, int lenHalfChunks) {
        this.trenchHalf = trenchHalfChunks;
        this.sideChunks = sideChunks;
        this.lenHalf = lenHalfChunks;
    }

    public boolean playable(int cx, int cz) {
        if (cz < -lenHalf || cz >= lenHalf) return false;
        int ax = cx >= 0 ? cx : -cx - 1; // Chunk-Abstand von der Mitte
        return ax >= trenchHalf && ax < trenchHalf + sideChunks;
    }

    @Override public boolean shouldGenerateNoise(WorldInfo w, Random r, int cx, int cz) { return playable(cx, cz); }
    @Override public boolean shouldGenerateSurface(WorldInfo w, Random r, int cx, int cz) { return playable(cx, cz); }
    @Override
    public void generateBedrock(WorldInfo w, Random r, int cx, int cz, ChunkData d) {
        if (!playable(cx, cz)) return;
        int min = d.getMinHeight();
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                d.setBlock(x, min, z, Material.BEDROCK);
                for (int i = 1; i <= 4; i++) {
                    if (r.nextInt(5) >= i) d.setBlock(x, min + i, z, Material.BEDROCK);
                }
            }
        }
    }
    @Override public boolean shouldGenerateCaves(WorldInfo w, Random r, int cx, int cz) { return playable(cx, cz); }
    @Override public boolean shouldGenerateDecorations(WorldInfo w, Random r, int cx, int cz) { return playable(cx, cz); }
    @Override public boolean shouldGenerateMobs(WorldInfo w, Random r, int cx, int cz) { return playable(cx, cz); }
    @Override public boolean shouldGenerateStructures(WorldInfo w, Random r, int cx, int cz) { return playable(cx, cz); }

    @Override
    public Location getFixedSpawnLocation(World world, Random random) {
        // Platzhalter, das Plugin setzt den echten Spawn nach dem Laden der Welt
        return new Location(world, -(trenchHalf * 16 + sideChunks * 8) + 0.5, 120, 0.5);
    }
}
