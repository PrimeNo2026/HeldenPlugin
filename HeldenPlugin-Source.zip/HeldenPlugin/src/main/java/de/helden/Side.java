package de.helden;

public enum Side {
    WEST("Westseite"),
    EAST("Ostseite");

    private final String display;

    Side(String display) {
        this.display = display;
    }

    public String display() {
        return display;
    }
}
