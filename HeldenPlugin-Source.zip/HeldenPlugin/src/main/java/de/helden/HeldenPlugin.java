package de.helden;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.EnumMap;
import java.util.Map;

public final class HeldenPlugin extends JavaPlugin {

    private HeldenGenerator generator;
    private World world;
    private Data data;
    private HeartListener hearts;
    private CorpseManager corpses;
    private int trenchHalfChunks;
    private int sideWidth;
    private final Map<Side, Location> spawns = new EnumMap<>(Side.class);

    @Override
    public void onLoad() {
        saveDefaultConfig();
        trenchHalfChunks = (int) Math.ceil(getConfig().getInt("trench-width", 224) / 32.0);
        sideWidth = getConfig().getInt("side-width", 4000);
        int sideChunks = (int) Math.ceil(sideWidth / 16.0);
        int lenHalf = (int) Math.ceil(getConfig().getInt("world-length", 20000) / 32.0);
        generator = new HeldenGenerator(trenchHalfChunks, sideChunks, lenHalf);
    }

    @Override
    public void onEnable() {
        WorldCreator wc = new WorldCreator(getConfig().getString("world-name", "helden")).generator(generator);
        long seed = getConfig().getLong("seed", 0);
        if (seed != 0) wc.seed(seed);
        world = wc.createWorld();
        if (world == null) {
            getLogger().severe("Welt konnte nicht erstellt werden!");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        data = new Data(this);
        computeSpawns();
        world.setSpawnLocation(spawns.get(Side.WEST));

        hearts = new HeartListener(this, data);
        corpses = new CorpseManager(this);
        getServer().getPluginManager().registerEvents(hearts, this);
        getServer().getPluginManager().registerEvents(corpses, this);
        getServer().getPluginManager().registerEvents(new WorldRulesListener(this), this);
        hearts.startTask();

        Commands cmd = new Commands(this);
        getCommand("allow").setExecutor(cmd);
        getCommand("allow").setTabCompleter(cmd);
        getCommand("helden").setExecutor(cmd);
        getCommand("helden").setTabCompleter(cmd);
    }

    @Override
    public void onDisable() {
        if (data != null) data.save();
        if (corpses != null) corpses.save();
    }

    @Override
    public ChunkGenerator getDefaultWorldGenerator(String worldName, String id) {
        return generator;
    }

    private void computeSpawns() {
        for (Side side : Side.values()) {
            int sign = side == Side.EAST ? 1 : -1;
            int cx = sign * (trenchHalfChunks * 16 + sideWidth / 2);
            Location found = null;
            for (int i = 0; i < 36 && found == null; i++) {
                int x = cx + sign * (i % 6) * 12;
                int z = (i / 6) * 12;
                Block top = world.getHighestBlockAt(x, z, HeightMap.MOTION_BLOCKING_NO_LEAVES);
                if (!top.isLiquid()) found = top.getLocation().add(0.5, 1, 0.5);
            }
            if (found == null) {
                found = world.getHighestBlockAt(cx, 0).getLocation().add(0.5, 1, 0.5);
            }
            spawns.put(side, found);
        }
    }

    public World world() { return world; }
    public Data data() { return data; }
    public HeartListener hearts() { return hearts; }
    public Location spawn(Side s) { return spawns.get(s).clone(); }

    /** true, wenn die X-Koordinate im Graben liegt. */
    public boolean inTrench(int x) {
        int half = trenchHalfChunks * 16;
        return x >= -half && x < half;
    }

    public boolean bridgesAllowed() {
        return getConfig().getBoolean("bridges-allowed", false);
    }

    public void setBridgesAllowed(boolean v) {
        getConfig().set("bridges-allowed", v);
        saveConfig();
    }
}
