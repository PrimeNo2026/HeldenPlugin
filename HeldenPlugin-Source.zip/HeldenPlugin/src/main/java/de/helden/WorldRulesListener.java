package de.helden;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityPortalEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerPortalEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.event.world.EntitiesLoadEvent;
import org.bukkit.event.world.PortalCreateEvent;
import org.bukkit.event.world.StructureGrowEvent;
import org.bukkit.generator.structure.GeneratedStructure;
import org.bukkit.generator.structure.StructurePiece;
import org.bukkit.generator.structure.Structure;
import org.bukkit.util.BoundingBox;

/** Keine Trial Chambers, keine Villager, kein Nether, Graben nur mit /allow bridges ueberbaubar. */
public final class WorldRulesListener implements Listener {

    private final HeldenPlugin plugin;

    public WorldRulesListener(HeldenPlugin plugin) {
        this.plugin = plugin;
    }

    // ------------------------------------------------------------------ Villager

    private static boolean isVillagerType(EntityType t) {
        return t == EntityType.VILLAGER || t == EntityType.ZOMBIE_VILLAGER
                || t == EntityType.WANDERING_TRADER || t == EntityType.TRADER_LLAMA;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onSpawn(CreatureSpawnEvent e) {
        if (isVillagerType(e.getEntityType())) e.setCancelled(true);
    }

    @EventHandler
    public void onEntitiesLoad(EntitiesLoadEvent e) {
        for (Entity en : e.getEntities()) {
            if (isVillagerType(en.getType())) en.remove();
        }
    }

    // ------------------------------------------------------------------ Nether

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPortal(PlayerPortalEvent e) {
        if (e.getCause() == PlayerTeleportEvent.TeleportCause.NETHER_PORTAL) {
            e.setCancelled(true);
            e.getPlayer().sendMessage(Component.text("Den Nether gibt es nicht.", NamedTextColor.RED));
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onEntityPortal(EntityPortalEvent e) {
        if (e.getTo() != null && e.getTo().getWorld() != null
                && e.getTo().getWorld().getEnvironment() == World.Environment.NETHER) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPortalCreate(PortalCreateEvent e) {
        if (e.getReason() == PortalCreateEvent.CreateReason.FIRE
                || e.getReason() == PortalCreateEvent.CreateReason.NETHER_PAIR) {
            e.setCancelled(true);
        }
    }

    // ------------------------------------------------------------------ Trial Chambers

    @EventHandler
    public void onChunkLoad(ChunkLoadEvent e) {
        if (!e.isNewChunk() || !e.getWorld().equals(plugin.world())) return;
        Chunk chunk = e.getChunk();
        Bukkit.getScheduler().runTask(plugin, () -> removeTrialChambers(chunk));
    }

    /** Fuellt alle Teile einer Trial Chamber in diesem Chunk mit Stein bzw. Deepslate auf. */
    private void removeTrialChambers(Chunk chunk) {
        if (!chunk.isLoaded()) return;
        for (GeneratedStructure gs : chunk.getStructures(Structure.TRIAL_CHAMBERS)) {
            for (StructurePiece piece : gs.getPieces()) {
                fill(chunk, piece.getBoundingBox());
            }
        }
    }

    private void fill(Chunk chunk, BoundingBox bb) {
        World w = chunk.getWorld();
        int x0 = Math.max(chunk.getX() * 16, (int) Math.floor(bb.getMinX()));
        int x1 = Math.min(chunk.getX() * 16 + 15, (int) Math.ceil(bb.getMaxX()) - 1);
        int z0 = Math.max(chunk.getZ() * 16, (int) Math.floor(bb.getMinZ()));
        int z1 = Math.min(chunk.getZ() * 16 + 15, (int) Math.ceil(bb.getMaxZ()) - 1);
        int y0 = Math.max(w.getMinHeight(), (int) Math.floor(bb.getMinY()));
        int y1 = Math.min(w.getMaxHeight() - 1, (int) Math.ceil(bb.getMaxY()) - 1);
        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                for (int y = y0; y <= y1; y++) {
                    Block b = w.getBlockAt(x, y, z);
                    if (b.getType() == Material.BEDROCK) continue;
                    b.setType(y < 0 ? Material.DEEPSLATE : Material.STONE, false);
                }
            }
        }
    }

    // ------------------------------------------------------------------ Graben

    private boolean blocked(Block b) {
        return plugin.inTrench(b.getX())
                && b.getWorld().equals(plugin.world())
                && !plugin.bridgesAllowed();
    }

    private void deny(Player p) {
        p.sendActionBar(Component.text("Der Graben darf noch nicht ueberbaut werden.", NamedTextColor.RED));
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (blocked(e.getBlock()) && !e.getPlayer().hasPermission("helden.bypass")) {
            e.setCancelled(true);
            deny(e.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucket(PlayerBucketEmptyEvent e) {
        if (blocked(e.getBlock()) && !e.getPlayer().hasPermission("helden.bypass")) {
            e.setCancelled(true);
            deny(e.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFlow(BlockFromToEvent e) {
        if (blocked(e.getToBlock())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onGrow(StructureGrowEvent e) {
        e.getBlocks().removeIf(s -> blocked(s.getBlock()));
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPiston(BlockPistonExtendEvent e) {
        for (Block b : e.getBlocks()) {
            if (blocked(b.getRelative(e.getDirection()))) {
                e.setCancelled(true);
                return;
            }
        }
        if (blocked(e.getBlock().getRelative(e.getDirection()))) e.setCancelled(true);
    }
}
