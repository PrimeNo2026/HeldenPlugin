package de.helden;

import de.helden.Data.PlayerState;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public final class Commands implements CommandExecutor, TabCompleter {

    private final HeldenPlugin plugin;

    public Commands(HeldenPlugin plugin) {
        this.plugin = plugin;
    }

    private void msg(CommandSender s, String text, NamedTextColor c) {
        s.sendMessage(Component.text(text, c));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("helden.admin")) {
            msg(sender, "Keine Berechtigung.", NamedTextColor.RED);
            return true;
        }

        if (cmd.getName().equalsIgnoreCase("allow")) {
            if (args.length < 1 || !args[0].equalsIgnoreCase("bridges")) {
                msg(sender, "Benutzung: /allow bridges [on|off]", NamedTextColor.RED);
                return true;
            }
            boolean value = !(args.length >= 2 && args[1].equalsIgnoreCase("off"));
            plugin.setBridgesAllowed(value);
            Bukkit.broadcast(Component.text(value
                    ? "Der Graben darf ab sofort ueberbaut werden!"
                    : "Das Bauen ueber den Graben ist wieder verboten.", NamedTextColor.GOLD));
            return true;
        }

        // /helden ...
        if (args.length == 0) {
            msg(sender, "/helden info [spieler] | revive <spieler> | hearts <spieler> <0-3>", NamedTextColor.YELLOW);
            return true;
        }
        Data data = plugin.data();
        switch (args[0].toLowerCase()) {
            case "info" -> {
                OfflinePlayer t = args.length >= 2 ? Bukkit.getOfflinePlayer(args[1])
                        : (sender instanceof Player p ? p : null);
                PlayerState s = t == null ? null : data.get(t.getUniqueId());
                if (s == null) {
                    msg(sender, "Kein Eintrag gefunden.", NamedTextColor.RED);
                    return true;
                }
                String partner = s.partner == null ? "-" : data.get(s.partner).name;
                msg(sender, s.name + ": " + s.side.display() + ", blaue Herzen: " + s.blue
                        + ", ausgeschieden: " + s.eliminated + ", Partner: " + partner, NamedTextColor.AQUA);
            }
            case "revive" -> {
                if (args.length < 2) return false;
                OfflinePlayer t = Bukkit.getOfflinePlayer(args[1]);
                PlayerState s = data.get(t.getUniqueId());
                if (s == null) {
                    msg(sender, "Kein Eintrag gefunden.", NamedTextColor.RED);
                    return true;
                }
                s.eliminated = false;
                s.blue = 3;
                s.partner = null;
                data.save();
                Player online = t.getPlayer();
                if (online != null) {
                    online.setGameMode(GameMode.SURVIVAL);
                    plugin.hearts().refresh(online, s);
                }
                msg(sender, s.name + " wurde wiederbelebt.", NamedTextColor.GREEN);
            }
            case "hearts" -> {
                if (args.length < 3) return false;
                OfflinePlayer t = Bukkit.getOfflinePlayer(args[1]);
                PlayerState s = data.get(t.getUniqueId());
                if (s == null) {
                    msg(sender, "Kein Eintrag gefunden.", NamedTextColor.RED);
                    return true;
                }
                int n;
                try {
                    n = Math.max(0, Math.min(3, Integer.parseInt(args[2])));
                } catch (NumberFormatException ex) {
                    return false;
                }
                s.blue = n;
                s.partner = null;
                if (n == 0) plugin.hearts().assignPartner(s);
                data.save();
                Player online = t.getPlayer();
                if (online != null) plugin.hearts().refresh(online, s);
                msg(sender, s.name + " hat jetzt " + n + " blaue Herzen.", NamedTextColor.GREEN);
            }
            default -> msg(sender, "Unbekannter Unterbefehl.", NamedTextColor.RED);
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (cmd.getName().equalsIgnoreCase("allow")) {
            if (args.length == 1) out.add("bridges");
            if (args.length == 2) { out.add("on"); out.add("off"); }
        } else {
            if (args.length == 1) { out.add("info"); out.add("revive"); out.add("hearts"); }
            if (args.length == 2) Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
        }
        String last = args.length == 0 ? "" : args[args.length - 1].toLowerCase();
        out.removeIf(s -> !s.toLowerCase().startsWith(last));
        return out;
    }
}
