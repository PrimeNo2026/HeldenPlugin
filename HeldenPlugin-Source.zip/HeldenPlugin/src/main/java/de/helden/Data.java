package de.helden;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.*;

/** Speichert Seite, Herzen, Partner und Ausscheiden aller Spieler dauerhaft in data.yml. */
public final class Data {

    public static final class PlayerState {
        public final UUID id;
        public String name = "?";
        public Side side = Side.WEST;
        public int blue = 3;               // blaue Herzen (0-3)
        public boolean eliminated = false; // true = Spectator, ausgeschieden
        public UUID partner = null;        // verlinkter Partner (nur relevant bei blue == 0)

        PlayerState(UUID id) {
            this.id = id;
        }
    }

    private final HeldenPlugin plugin;
    private final File file;
    private final Map<UUID, PlayerState> states = new LinkedHashMap<>();
    private int joinCounter = 0;

    public Data(HeldenPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "data.yml");
        load();
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        joinCounter = y.getInt("join-counter", 0);
        ConfigurationSection players = y.getConfigurationSection("players");
        if (players == null) return;
        for (String key : players.getKeys(false)) {
            ConfigurationSection s = players.getConfigurationSection(key);
            if (s == null) continue;
            PlayerState st = new PlayerState(UUID.fromString(key));
            st.name = s.getString("name", "?");
            st.side = Side.valueOf(s.getString("side", "WEST"));
            st.blue = s.getInt("blue", 3);
            st.eliminated = s.getBoolean("eliminated", false);
            String partner = s.getString("partner");
            st.partner = partner == null ? null : UUID.fromString(partner);
            states.put(st.id, st);
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        y.set("join-counter", joinCounter);
        for (PlayerState st : states.values()) {
            String p = "players." + st.id;
            y.set(p + ".name", st.name);
            y.set(p + ".side", st.side.name());
            y.set(p + ".blue", st.blue);
            y.set(p + ".eliminated", st.eliminated);
            y.set(p + ".partner", st.partner == null ? null : st.partner.toString());
        }
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (IOException ex) {
            plugin.getLogger().severe("Konnte data.yml nicht speichern: " + ex.getMessage());
        }
    }

    public PlayerState get(UUID id) {
        return states.get(id);
    }

    public Collection<PlayerState> all() {
        return states.values();
    }

    /** Holt den Spieler-Status; neue Spieler werden abwechselnd einer Seite zugeteilt. */
    public PlayerState getOrCreate(Player p) {
        PlayerState s = states.get(p.getUniqueId());
        if (s == null) {
            s = new PlayerState(p.getUniqueId());
            s.side = (joinCounter++ % 2 == 0) ? Side.WEST : Side.EAST;
            states.put(s.id, s);
            s.name = p.getName();
            save();
        }
        s.name = p.getName();
        return s;
    }
}
